package com.zcf.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint; 
  
@Entity  //会在数据库生成表信息 
@Table(name="student",uniqueConstraints = {@UniqueConstraint(columnNames="studentNumber")})//表名称
public class Student {
	@Id 
	@GeneratedValue(strategy=GenerationType.AUTO)// 指定主键以及主键自增长
	Integer id; 
	String  studentNumber;
	String studentName;
	String classNumber; 
	String className;
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getStudentNumber() {
		return studentNumber;
	}
	public void setStudentNumber(String studentNumber) {
		this.studentNumber = studentNumber;
	}
	public String getStudentName() {
		return studentName;
	}
	public void setStudentName(String studentName) {
		this.studentName = studentName;
	}
    
	public String getClassNumber() {
		return classNumber;
	}
	public void setClassNumber(String classNumber) {
		this.classNumber = classNumber;
	}
	public String getClassName() {
		return className;
	}
	public void setClassName(String className) {
		this.className = className;
	}
	@Override
	public String toString() {
		return "Student [id=" + id + ", studentNumber=" + studentNumber + ", studentName=" + studentName
				+ ", classNumber=" + classNumber + ", className=" + className + "]";
	}
	 
	 
	
}
