package com.zcf.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

@Entity  //会在数据库生成表信息
@Table(name="teacher",uniqueConstraints = {@UniqueConstraint(columnNames="teacherNumber")})//表名称
public class Teacher {

	@Id 
	@GeneratedValue(strategy=GenerationType.AUTO)// 指定主键以及主键自增长
	Integer id=0; 

	@Column(name = "teacherNumber",nullable = false,unique = true)  
	String teacherNumber;
	String teacherName;
	String department;
	 
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getTeacherNumber() {
		return teacherNumber;
	}
	public void setTeacherNumber(String teacherNumber) {
		this.teacherNumber = teacherNumber;
	}
	public String getTeacherName() {
		return teacherName;
	}
	public void setTeacherName(String teacherName) {
		this.teacherName = teacherName;
	}
	public String getDepartment() {
		return department;
	}
	public void setDepartment(String department) {
		this.department = department;
	}
	@Override
	public String toString() {
		return "Teacher [id=" + id + ", teacherNumber=" + teacherNumber + ", teacherName=" + teacherName
				+ ", department=" + department + "]";
	}
	
}
