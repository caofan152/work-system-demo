package com.zcf.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

@Entity  //会在数据库生成表信息
@Table(name="clazz",uniqueConstraints = {@UniqueConstraint(columnNames="classNumber")})//表名称
public class Clazz { 
	@Id 
	@GeneratedValue(strategy=GenerationType.AUTO)// 指定主键以及主键自增长
	Integer id; 

	@Column(name = "classNumber",nullable = false,unique = true)  
	String classNumber;
	String className;  
	Integer studentCount=0;
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getClassNumber() {
		return classNumber;
	}
	public void setClassNumber(String classNumber) {
		this.classNumber = classNumber;
	}
	public String getclassName() {
		return className;
	}
	public void setclassName(String className) {
		this.className = className;
	}
	
	public Integer getStudentCount() {
		return studentCount;
	}
	public void setStudentCount(Integer studentCount) {
		this.studentCount = studentCount;
	}
	@Override
	public String toString() {
		return "Clazz [id=" + id + ", classNumber=" + classNumber + ", className=" + className + ", studentCount="
				+ studentCount + "]";
	}
 
	
}
