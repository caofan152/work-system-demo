package com.zcf.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table; 

@Entity  //会在数据库生成表信息
@Table(name="user"  )//表名称
public class User{ 

	@Id  
	@GeneratedValue(strategy=GenerationType.AUTO)// 指定自增长
    int id; 
  
	@Column(name = "account",nullable = false,unique = true)
    String account;
	
	@Column(name = "password",nullable = false)
    String password;
	
    int userType; 
 

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getAccount() {
		return account;
	}

	public void setAccount(String account) {
		this.account = account;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public int getUserType() {
		return userType;
	}

	public void setUserType(int userType) {
		this.userType = userType;
	}

	 
    
	 
    
}
