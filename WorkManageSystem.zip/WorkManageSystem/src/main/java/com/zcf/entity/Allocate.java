package com.zcf.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

@Entity  //会在数据库生成表信息
@Table(name="course_class",uniqueConstraints = {@UniqueConstraint(columnNames="classNumber")})//表名称
public class Allocate {
	@Id 
	@GeneratedValue(strategy=GenerationType.AUTO)// 指定主键以及主键自增长
	Integer id; 
	String courseNumber;
	String courseName;
	String classNumber;
	String className;
	String teacherName;
	
	public String getTeacherName() {
		return teacherName;
	}
	public void setTeacherName(String teacherName) {
		this.teacherName = teacherName;
	}
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getCourseNumber() {
		return courseNumber;
	}
	public void setCourseNumber(String courseNumber) {
		this.courseNumber = courseNumber;
	}
	public String getCourseName() {
		return courseName;
	}
	public void setCourseName(String courseName) {
		this.courseName = courseName;
	}
	public String getClassNumber() {
		return classNumber;
	}
	public void setClassNumber(String classNumber) {
		this.classNumber = classNumber;
	}
	public String getClassName() {
		return className;
	}
	public void setClassName(String className) {
		this.className = className;
	}
	@Override
	public String toString() {
		return "Allocate [id=" + id + ", courseNumber=" + courseNumber + ", courseName=" + courseName + ", classNumber="
				+ classNumber + ", className=" + className + ", teacherName=" + teacherName + "]";
	}
	
}
