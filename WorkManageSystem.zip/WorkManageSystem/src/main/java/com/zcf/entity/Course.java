package com.zcf.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

@Entity  //会在数据库生成表信息
@Table(name="Course",uniqueConstraints = {@UniqueConstraint(columnNames="courseNumber")})//表名称
public class Course {
	@Id 
	@GeneratedValue(strategy=GenerationType.AUTO)// 指定主键以及主键自增长
	Integer id; 
	String courseName;
	String courseNumber;
	String courseTeacherNumber;
	String courseTeacherName;
	
	public String getCourseTeacherName() {
		return courseTeacherName;
	}
	public void setCourseTeacherName(String courseTeacherName) {
		this.courseTeacherName = courseTeacherName;
	}
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getCourseName() {
		return courseName;
	}
	public void setCourseName(String courseName) {
		this.courseName = courseName;
	}
	public String getCourseNumber() {
		return courseNumber;
	}
	public void setCourseNumber(String courseNumber) {
		this.courseNumber = courseNumber;
	}
	public String getCourseTeacherNumber() {
		return courseTeacherNumber;
	}
	public void setCourseTeacherNumber(String courseTeacherNumber) {
		this.courseTeacherNumber = courseTeacherNumber;
	}
	@Override
	public String toString() {
		return "Course [id=" + id + ", courseName=" + courseName + ", courseNumber=" + courseNumber
				+ ", courseTeacherNumber=" + courseTeacherNumber + ", courseTeacherName=" + courseTeacherName + "]";
	}
	 
}
