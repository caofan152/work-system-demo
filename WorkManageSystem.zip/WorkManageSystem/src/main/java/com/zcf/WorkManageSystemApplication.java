package com.zcf;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.boot.web.servlet.ServletComponentScan;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
 

@SpringBootApplication  
@ServletComponentScan // 扫描使用注解方式的servlet
@EnableJpaRepositories(basePackages = "com.zcf.repository")
@EntityScan(basePackages = "com.zcf.entity") 
public class WorkManageSystemApplication extends SpringBootServletInitializer{ 
	public static void main(String[] args) {
		SpringApplication.run(WorkManageSystemApplication.class, args);
	}  
 
}
