package com.zcf.repository;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;

import com.zcf.entity.Course;

@Transactional
public interface CourseRepository extends JpaRepository<Course, Integer>{ 
	  
    @SuppressWarnings("unchecked") 
    public Course save(Course u);
    
    @Query(value ="select cl.id, cl.course_name,cl.course_number,cl.course_teacher_number,cl.course_teacher_name from course cl where 1=1" , nativeQuery = true)
    public List<Course> findAll();
    
    @Query(value = "delete from course where course_number=?1", nativeQuery = true)
    @Modifying
    public void deleteByCourseNumber(String courseNumber);
    
//    @Query(value = "update course cl set cl.course_name=?3, cl.course_number=?2 where cl.course_number=?1", nativeQuery = true)
//    @Modifying
//    public int updateCourse(String oldCourseNumber,String courseNumber,String courseName);
}
