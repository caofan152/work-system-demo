package com.zcf.repository;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
 
import com.zcf.entity.Teacher;
@Transactional
public interface TeacherRepository extends JpaRepository<Teacher, Integer>{
	@SuppressWarnings("unchecked") 
    public Teacher save(Teacher u);
    
    @Query(value ="select tb.id, tb.teacher_name,tb.teacher_number,tb.department from teacher tb where 1=1" , nativeQuery = true)
    public List<Teacher> findAll();
    
    @Query(value = "delete from teacher where teacher_number=?1", nativeQuery = true)
    @Modifying
    public void deleteByTeacherNumber(String teacherNumber);
    
    @Query(value = "update teacher cl set cl.teacher_name=?3, cl.teacher_number=?2, cl.department=?4 where cl.teacher_number=?1", nativeQuery = true)
    @Modifying
    public int updateTeacher(String oldTeacherNumber,String teacher,String teacherName,String department);
}
