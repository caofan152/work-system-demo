package com.zcf.repository;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;

import com.zcf.entity.Clazz; 

@Transactional
public interface ClazzRepository extends JpaRepository<Clazz, Integer>{ 
  
	    @SuppressWarnings("unchecked") 
	    public Clazz save(Clazz u);
	    
	    @Query(value ="select cl.id, cl.class_name,cl.class_number,cl.student_count from clazz cl where 1=1" , nativeQuery = true)
	    public List<Clazz> findAll();
	    
	    @Query(value = "delete from clazz where class_number=?1", nativeQuery = true)
	    @Modifying
	    public void deleteByClassNumber(String classNumber);
	    
	    @Query(value = "update clazz cl set cl.class_name=?3, cl.class_number=?2 where cl.class_number=?1", nativeQuery = true)
	    @Modifying
	    public int updateClass(String oldClassNumber,String classNumber,String className);
	    
	    @Query(value = "update clazz cl set cl.student_count=cl.student_count+1 where cl.class_number=?1", nativeQuery = true)
	    @Modifying
	    public int addStudentCount(String classNumber);
	    
	    @Query(value = "update clazz cl set cl.student_count=cl.student_count-1 where cl.class_number=?1", nativeQuery = true)
	    @Modifying
	    public int decreaseStudentCount(String classNumber);
}

