package com.zcf.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;

import com.zcf.entity.User;

 
public interface UserRepository extends JpaRepository<User, Integer>{
 
 	    @SuppressWarnings("unchecked") 
 	    public User save(User u);
        
 	    @Query(value = "update user u set u.account=?1 where u.account=?1", nativeQuery = true)
	    @Modifying
 	    public User updateByNumber(String number);
	    //@Query("select t from user t where t.name=:name")
	     //public User findUserByAccount(String account); 
}
