package com.zcf.repository;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;

import com.zcf.entity.Allocate;

@Transactional
public interface AllocateRepository  extends JpaRepository<Allocate, Integer>{
    @SuppressWarnings("unchecked") 
    public Allocate save(Allocate u);
    
    //@Query(value ="select cl.id, cl.course_name,cl.course_number,cl.course_teacher_number,cl.course_teacher_name from course cl where 1=1" , nativeQuery = true)
   // public List<Allocate> findAll();
    
    public List<Allocate> findAllByCourseNumber(String courseNumber);
    
    @Query(value = "delete from course_class where id=?1", nativeQuery = true)
    @Modifying
    public void deleteByAllocateId(String id);
}
