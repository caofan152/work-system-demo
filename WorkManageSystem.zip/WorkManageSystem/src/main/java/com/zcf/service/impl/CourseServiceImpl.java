package com.zcf.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.zcf.entity.Course;
import com.zcf.repository.CourseRepository;
import com.zcf.service.CourseService;
@Service
public class CourseServiceImpl implements CourseService{
	@Autowired
	@Qualifier("courseRepository") 
	private CourseRepository courseRepository;
	@Override
	public Course save(Course u) { 
		return courseRepository.save(u);
	}

	@Override
	public List<Course> findAll() {
		 
		return courseRepository.findAll();
	}

	@Override
	public void deleteByCourseNumber(String courseNumber) {
		courseRepository.deleteByCourseNumber(courseNumber); 
	}

//	@Override
//	public int updateCourse(String oldCourseNumber, String courseNumber, String courseName) {
//		 
//		return courseRepository.updateCourse(oldCourseNumber, courseNumber, courseName);
//	}

}
