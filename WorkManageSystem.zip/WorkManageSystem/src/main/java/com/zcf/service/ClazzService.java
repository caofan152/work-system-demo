package com.zcf.service;

import java.util.List;

import com.zcf.entity.Clazz; 


public interface ClazzService {  
 
    public Clazz save(Clazz u);/*添加班级*/
	
    public List<Clazz> findAll(); /*查询所有班级*/ 
    public void deleteByClassNumber(String classNumber);/*通过班级编号删除班级列表*/
     
    public int updateClass(String oldClassNumber,String classNumber,String className);/*通过班级编号更新班级信息*/
    
    public int addStudentCount(String classNumber);/*学生数量字段增1*/
    public int decreaseStudentCount(String classNumber);/*学生数量字段减1*/
}
