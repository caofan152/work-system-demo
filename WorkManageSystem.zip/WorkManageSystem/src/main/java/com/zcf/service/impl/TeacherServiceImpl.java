package com.zcf.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.zcf.entity.Teacher;
import com.zcf.repository.TeacherRepository;
import com.zcf.service.TeacherService;

@Service
public class TeacherServiceImpl implements TeacherService{

	@Autowired
	@Qualifier("teacherRepository") 
	private TeacherRepository teacherRepository;
	@Override
	public Teacher save(Teacher u) { 
		return teacherRepository.save(u);
	}

	@Override
	public List<Teacher> findAll() { 
		return teacherRepository.findAll();
	}

	@Override
	public void deleteByTeacherNumber(String teacherNumber) {
		teacherRepository.deleteByTeacherNumber(teacherNumber); 
	}

	@Override
	public int updateTeacher(String oldTeacherNumber, String teacherNumber, String teacherName, String department) {
		 
		return teacherRepository.updateTeacher(oldTeacherNumber, teacherNumber, teacherName, department);
	}

	 

}
