package com.zcf.service;

import java.util.List; 

import com.zcf.entity.Allocate;

public interface AllocateService { 
    public Allocate save(Allocate u);
    
    //@Query(value ="select cl.id, cl.course_name,cl.course_number,cl.course_teacher_number,cl.course_teacher_name from course cl where 1=1" , nativeQuery = true)
    public List<Allocate> findAll();
    public List<Allocate> findAllByCourseNumber(String courseNumber);
    public void deleteByAllocateId(String id);
}
