package com.zcf.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.zcf.entity.Student; 
@Service
public interface StudentService {
	public Student save(Student student);   

    public List<Student> findAll(); 
    public List<Student> findAllByClassNumber(String classNumber); 
     
    public void deleteById(Integer id);

    public Student getById(Integer id) ;
}
