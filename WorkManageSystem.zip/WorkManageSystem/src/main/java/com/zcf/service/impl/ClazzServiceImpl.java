package com.zcf.service.impl;

import java.util.List;
 

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.zcf.entity.Clazz;
import com.zcf.repository.ClazzRepository;
import com.zcf.service.ClazzService;
@Service
public class ClazzServiceImpl implements ClazzService{ 

	@Autowired
	@Qualifier("clazzRepository")
	//@Resource(name="clazzRepository")
	private ClazzRepository clazzRepository;
	
//	@Resource(name="clazzRepository")
//	public void setClazzRepository(ClazzRepository clazzRepository) {
//		this.clazzRepository = clazzRepository;
//	}

	@Override
	public Clazz save(Clazz u) { 
		return clazzRepository.save(u);
	}

	@Override
	public List<Clazz> findAll() { 
		System.out.println(clazzRepository);
		return clazzRepository.findAll();
	}

	@Override
	public void deleteByClassNumber(String classNumber) { 
		clazzRepository.deleteByClassNumber(classNumber);
	}

	@Override
	public int updateClass(String oldClassNumber, String classNumber, String className) { 
		return clazzRepository.updateClass(oldClassNumber, classNumber, className);
	}

	@Override
	public int addStudentCount(String classNumber) { 
		return clazzRepository.addStudentCount(classNumber);
	}
	
	@Override
	public int decreaseStudentCount(String classNumber) { 
		return clazzRepository.decreaseStudentCount(classNumber);
	}
}
