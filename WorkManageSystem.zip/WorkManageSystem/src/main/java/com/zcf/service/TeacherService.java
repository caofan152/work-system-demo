package com.zcf.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.zcf.entity.Teacher;

@Service
public interface TeacherService {
	 
    public Teacher save(Teacher u);
	
    public List<Teacher> findAll(); 
     
    public void deleteByTeacherNumber(String teacherNumber);
     
    public int updateTeacher(String oldTeacherNumber,String TeacherNumber,String TeacherName,String department);
}
