package com.zcf.service;

import java.util.List;

import com.zcf.entity.Course;

public interface CourseService {
	public Course save(Course u);
	
    public List<Course> findAll(); 
     
    public void deleteByCourseNumber(String courseNumber);
      
}
