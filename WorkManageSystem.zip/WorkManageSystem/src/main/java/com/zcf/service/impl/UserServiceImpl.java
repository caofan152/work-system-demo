package com.zcf.service.impl;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.zcf.entity.User;
import com.zcf.repository.UserRepository;
import com.zcf.service.UserService;

@Service
public class UserServiceImpl implements UserService{
	@Resource
	private UserRepository userRepository;

	@Override
	public User save(User user) {
		return userRepository.save(user);
	}
//	public User getUserByAccount(String account) {
//		return userRepository.findUserByAccount(account);
//	}
	
	 
}