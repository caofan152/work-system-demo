package com.zcf.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.zcf.entity.Allocate;
import com.zcf.repository.AllocateRepository;
import com.zcf.service.AllocateService;
@Service
public class AllocateServiceImpl implements AllocateService{
	@Autowired
	@Qualifier("allocateRepository")
	private AllocateRepository allocateRepository;
	@Override
	public Allocate save(Allocate u) { 
		return allocateRepository.save(u);
	} 
	@Override
	public List<Allocate> findAll() {
		
		return allocateRepository.findAll();
	} 
	@Override
	public void deleteByAllocateId(String id) { 
		allocateRepository.deleteByAllocateId(id);;
	}
	@Override
	public List<Allocate> findAllByCourseNumber(String courseNumber) {
		 
		return allocateRepository.findAllByCourseNumber(courseNumber);
	}

}
