package com.zcf.service;

import java.util.List;

import javax.annotation.Resource;
import javax.transaction.Transactional;

import org.springframework.stereotype.Service;

import com.zcf.entity.User;
import com.zcf.repository.UserRepository;

@Service
public interface UserService {   
	public User save(User user);
	
}