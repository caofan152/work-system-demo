package com.zcf.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.zcf.entity.Student;
import com.zcf.repository.StudentRepository;
import com.zcf.service.StudentService;
@Service
public class StudentServiceImpl  implements StudentService{
	@Autowired
	@Qualifier("studentRepository") 
	private StudentRepository studentRepository;
	@Override
	public Student save(Student student) {
		 
		return studentRepository.save(student);
	}

	@Override
	public List<Student> findAllByClassNumber(String classNumber) {
		 
		return studentRepository.findAllByClassNumber(classNumber);
	}

	@Override
	public void deleteById(Integer id) { 
		studentRepository.deleteById(id);
	}

	@Override
	public Student getById(Integer id) {
		  return studentRepository.getById(id);
	}

	@Override
	public List<Student> findAll() { 
		return studentRepository.findAll();
	}

}
