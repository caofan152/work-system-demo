package com.zcf.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.zcf.entity.Course;
import com.zcf.service.CourseService;
@Controller
public class CourseController {
	@Autowired
	private CourseService courseService;
	
	@RequestMapping("/addCourse")   
	@ResponseBody
    public int addCourse(@RequestBody Course course  ) {  

		System.out.println("进入 addCourse"); 
    	try {
    		courseService.save(course);
		}catch(Exception e) {
			System.out.println(e);
			return 0;
		}
        return 1; 
    }
	@RequestMapping("/updateCourse")  
	@ResponseBody
    public int updateCourse(@RequestBody Course course ) {  
		System.out.println("进入 updateCourse"); 
//		String oldCourseNumber=request.getParameter("oldCourseNumber");
//		String courseNumber=request.getParameter("courseNumber");
//		String courseName=request.getParameter("courseName");
    	try {
    		courseService.save(course);
    		//courseService.updateCourse(oldCourseNumber,courseNumber,courseName);
		}catch(Exception e) {
			System.out.println(e);
			return 0;
		}
		System.out.println("出 updateCourse");
        return 1; 
    }
	@RequestMapping("/queryCourse")
	@ResponseBody
    public Map<String,Object> queryCourse() { 
		System.out.println("进入 queryCourse");
    	List<Course> list=courseService.findAll(); 
    	Map<String,Object> model=new HashMap<String,Object>(1);
    	model.put("course",list); 
        return model;   
    }
	
	@RequestMapping("/deleteCourse")
	@ResponseBody
    public int deleteCourse(HttpServletRequest request) { 
		System.out.println("进入 deleteCourse");
		//request.setAttribute("personId",12);
		String courseNumber=request.getParameter("courseNumber");
		System.out.println(courseNumber); 
		try {
			courseService.deleteByCourseNumber(courseNumber); 
		}catch(Exception e) {
			System.out.println(e);
			return 0;
		}
        return 1;   
    } 
}
