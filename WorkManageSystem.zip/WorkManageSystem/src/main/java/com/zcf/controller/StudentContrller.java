package com.zcf.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.zcf.entity.Student;
import com.zcf.entity.User;
import com.zcf.service.ClazzService;
import com.zcf.service.StudentService;
import com.zcf.service.UserService;

@Controller
public class StudentContrller {
	@Autowired  
	private StudentService studentService ;
	@Autowired  
	private UserService userService ;
	@Autowired  
	private ClazzService clazzService ;
	
	@RequestMapping("/addStudent")   
	@ResponseBody
    public int addStudent(@RequestBody Student student  ) {   
    	try {
    		studentService.save(student);
    		User u=new User();
    		u.setAccount(student.getStudentNumber());
    		u.setPassword(student.getStudentNumber());
    		u.setUserType(3);
    		userService.save(u);
    		clazzService.addStudentCount(student.getClassNumber());
		}catch(Exception e) {
			System.out.println(e);
			return 0;
		}
        return 1; 
    }
	@RequestMapping("/updateStudent")  
	@ResponseBody
    public int updateStudent(@RequestBody Student student ) { 
		System.out.println("进入 updateStudent");  
    	try {
    		studentService.save(student); 
		}catch(Exception e) {
			System.out.println(e);
			return 0;
		}
        return 1; 
    }
	@RequestMapping("/queryStudent")
	@ResponseBody
    public Map<String,Object> queryStudent(HttpServletRequest request) { 
		System.out.println("进入 queryStudent");
		String classNumber=request.getParameter("classNumber");
    	List<Student> list;
    	if(classNumber.equals("")) {
    		list=studentService.findAll();
    	}else { 
    		list=studentService.findAllByClassNumber(classNumber);
    	}
    	for(int i=0;i<list.size();i++)System.out.println(list.get(i)); 
    	Map<String,Object> model=new HashMap<String,Object>(1);
    	model.put("student",list); 
        return model;   
    }
	
	@RequestMapping("/deleteStudent")
	@ResponseBody
    public int deletestudent(HttpServletRequest request) { 
		System.out.println("进入 deleteStudent"); 
		String id=request.getParameter("id"); 
		try {
			Student student=studentService.getById(Integer.parseInt(id));
			studentService.deleteById(Integer.parseInt(id)); 
			clazzService.decreaseStudentCount(student.getClassNumber());
		}catch(Exception e) {
			System.out.println(e);
			return 0;
		}
        return 1;   
    } 
}
