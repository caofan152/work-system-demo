package com.zcf.controller;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.zcf.entity.Clazz;
import com.zcf.service.ClazzService; 

  
@Controller
public class ClassController {  
 
	@Autowired  
	private ClazzService clazzService ; 
	
	@RequestMapping("/addClazz")   
	@ResponseBody
    public int addClazz(@RequestBody Clazz clazz  ) {
		System.out.println("进入 updateClazz");   
    	try {
    		clazzService.save(clazz);
		}catch(Exception e) {
			System.out.println(e);

			System.out.println("GG updateClazz"); 
			return 0;
		}
		System.out.println("出 updateClazz"); 
        return 1; 
    }
	@RequestMapping("/updateClazz")  
	@ResponseBody
    public int updateClazz(HttpServletRequest request ) {  
		System.out.println("进入 updateClazz"); 
		String oldClassNumber=request.getParameter("oldClassNumber");
		String classNumber=request.getParameter("classNumber");
		String className=request.getParameter("className");
    	try {
    		clazzService.updateClass(oldClassNumber,classNumber,className);
		}catch(Exception e) {
			System.out.println(e);
			return 0;
		}
		System.out.println("出 updateClazz");
        return 1; 
    }
	@RequestMapping("/queryClazz")
	@ResponseBody
    public Map<String,Object> queryClazz() { 
		System.out.println("进入 queryClazz");
    	List<Clazz> list=clazzService.findAll(); 
    	Map<String,Object> model=new HashMap<String,Object>(1);
    	model.put("class",list); 
        return model;   
    }
	
	@RequestMapping("/deleteClazz")
	@ResponseBody
    public int deleteClazz(HttpServletRequest request) { 
		System.out.println("进入 deleteClazz");
		//request.setAttribute("personId",12);
		String classNumber=request.getParameter("classNumber");
		System.out.println(classNumber); 
		try {
			clazzService.deleteByClassNumber(classNumber); 
		}catch(Exception e) {
			System.out.println(e);
			return 0;
		}
        return 1;   
    } 
}
