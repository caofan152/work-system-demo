package com.zcf.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.zcf.entity.Allocate; 
import com.zcf.service.AllocateService;

@Controller
public class AllocateController {
	@Autowired
	private AllocateService allocateService;
	
	@RequestMapping("/addAllocate")   
	@ResponseBody
    public int addAllocate(@RequestBody Allocate allocate  ) {  

		System.out.println("进入 addAllocate"); 
    	try {
    		allocateService.save(allocate);
		}catch(Exception e) {
			System.out.println(e);
			return 0;
		}
        return 1; 
    }
	@RequestMapping("/updateAllocate")  
	@ResponseBody
    public int updateallocate(@RequestBody Allocate allocate ) {  
		System.out.println("进入 updateAllocate");  
    	try {
    		allocateService.save(allocate); 
		}catch(Exception e) {
			System.out.println(e);
			return 0;
		}
		System.out.println("出 updateallocate");
        return 1; 
    }
	@RequestMapping("/queryAllocate")
	@ResponseBody
    public Map<String,Object> queryallocate(HttpServletRequest request) { 
		System.out.println("进入 queryAllocate");
		String courseNumber=request.getParameter("courseNumber");
    	List<Allocate> list=allocateService.findAllByCourseNumber(courseNumber);
    	Map<String,Object> model=new HashMap<String,Object>(1);
    	model.put("allocate",list); 
        return model;   
    }
	
	@RequestMapping("/deleteAllocate")
	@ResponseBody
    public int deleteallocate(HttpServletRequest request) { 
		System.out.println("进入 deleteAllocate"); 
		String id=request.getParameter("id"); 
		try {
			allocateService.deleteByAllocateId(id); 
		}catch(Exception e) {
			System.out.println(e);
			return 0;
		}
        return 1;   
    } 
	@RequestMapping("/getAllocatePage") 
    public String getAllocatePage(Model model,HttpServletRequest request) { 
		System.out.println("进入 getAllocatePage");  
		String courseNumber=request.getParameter("courseNumber");
		model.addAttribute("courseNumber", courseNumber);
        return "admin/course-teacher-manage";   
    }
}
