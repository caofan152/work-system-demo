package com.zcf.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.zcf.entity.Teacher;
import com.zcf.entity.User;
import com.zcf.service.TeacherService;
import com.zcf.service.UserService;

@Controller
public class TeacherController {
	@Autowired  
	private TeacherService teacherService ;
	@Autowired  
	private UserService userService ;
	
	@RequestMapping("/addTeacher")   
	@ResponseBody
    public int addTeacher(@RequestBody Teacher teacher  ) {   
    	try {
    		User u=new User();
    		u.setAccount(teacher.getTeacherNumber());
    		u.setPassword(teacher.getTeacherNumber());
    		u.setUserType(2);
    		userService.save(u);
    		teacherService.save(teacher);
		}catch(Exception e) {
			System.out.println(e);
			return 0;
		}
        return 1; 
    }
	@RequestMapping("/updateTeacher")  
	@ResponseBody
    public int updateTeacher(HttpServletRequest request ) { 
		System.out.println("进入 updateTeacher");  
		String oldTeacherNumber=request.getParameter("oldTeacherNumber");
		String teacherNumber=request.getParameter("teacherNumber");
		String teacherName=request.getParameter("teacherName");
		String department=request.getParameter("department"); 
		System.out.println(department);  
    	try {
    		teacherService.updateTeacher(oldTeacherNumber,teacherNumber,teacherName,department);
    		
		}catch(Exception e) {
			System.out.println(e);
			return 0;
		}
        return 1; 
    }
	@RequestMapping("/queryTeacher")
	@ResponseBody
    public Map<String,Object> queryTeacher() { 
		System.out.println("进入 queryTeacher");
    	List<Teacher> list=teacherService.findAll();
    	for(int i=0;i<list.size();i++)System.out.println(list.get(i)); 
    	Map<String,Object> model=new HashMap<String,Object>(1);
    	model.put("teacher",list); 
        return model;   
    }
	
	@RequestMapping("/deleteTeacher")
	@ResponseBody
    public int deleteTeacher(HttpServletRequest request) { 
		System.out.println("进入 deleteTeacher");
		//request.setAttribute("personId",12);
		String teacherNumber=request.getParameter("teacherNumber");
		System.out.println(teacherNumber); 
		try {
			teacherService.deleteByTeacherNumber(teacherNumber); 
		}catch(Exception e) {
			System.out.println(e);
			return 0;
		}
        return 1;   
    } 
}
